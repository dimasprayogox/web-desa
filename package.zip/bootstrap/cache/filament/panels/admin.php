<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.berita-resource.pages.create-berita' => 'App\\Filament\\Resources\\BeritaResource\\Pages\\CreateBerita',
    'app.filament.resources.berita-resource.pages.edit-berita' => 'App\\Filament\\Resources\\BeritaResource\\Pages\\EditBerita',
    'app.filament.resources.berita-resource.pages.list-beritas' => 'App\\Filament\\Resources\\BeritaResource\\Pages\\ListBeritas',
    'app.filament.resources.demografi-detail-resource.pages.create-demografi-detail' => 'App\\Filament\\Resources\\DemografiDetailResource\\Pages\\CreateDemografiDetail',
    'app.filament.resources.demografi-detail-resource.pages.edit-demografi-detail' => 'App\\Filament\\Resources\\DemografiDetailResource\\Pages\\EditDemografiDetail',
    'app.filament.resources.demografi-detail-resource.pages.list-demografi-details' => 'App\\Filament\\Resources\\DemografiDetailResource\\Pages\\ListDemografiDetails',
    'app.filament.resources.demografi-detail-resource.pages.view-demografi-detail' => 'App\\Filament\\Resources\\DemografiDetailResource\\Pages\\ViewDemografiDetail',
    'app.filament.resources.demografi-dusun-resource.pages.create-demografi-dusun' => 'App\\Filament\\Resources\\DemografiDusunResource\\Pages\\CreateDemografiDusun',
    'app.filament.resources.demografi-dusun-resource.pages.edit-demografi-dusun' => 'App\\Filament\\Resources\\DemografiDusunResource\\Pages\\EditDemografiDusun',
    'app.filament.resources.demografi-dusun-resource.pages.list-demografi-dusuns' => 'App\\Filament\\Resources\\DemografiDusunResource\\Pages\\ListDemografiDusuns',
    'app.filament.resources.demografi-dusun-resource.pages.view-demografi-dusun' => 'App\\Filament\\Resources\\DemografiDusunResource\\Pages\\ViewDemografiDusun',
    'app.filament.resources.detail-apbdes.pages.create-detail-apbdes' => 'App\\Filament\\Resources\\DetailApbdes\\Pages\\CreateDetailApbdes',
    'app.filament.resources.detail-apbdes.pages.edit-detail-apbdes' => 'App\\Filament\\Resources\\DetailApbdes\\Pages\\EditDetailApbdes',
    'app.filament.resources.detail-apbdes.pages.list-detail-apbdes' => 'App\\Filament\\Resources\\DetailApbdes\\Pages\\ListDetailApbdes',
    'app.filament.resources.kategori-umkm-resource.pages.create-kategori-umkm' => 'App\\Filament\\Resources\\KategoriUmkmResource\\Pages\\CreateKategoriUmkm',
    'app.filament.resources.kategori-umkm-resource.pages.edit-kategori-umkm' => 'App\\Filament\\Resources\\KategoriUmkmResource\\Pages\\EditKategoriUmkm',
    'app.filament.resources.kategori-umkm-resource.pages.list-kategori-umkms' => 'App\\Filament\\Resources\\KategoriUmkmResource\\Pages\\ListKategoriUmkms',
    'app.filament.resources.laporan-apbdes.pages.create-laporan-apbdes' => 'App\\Filament\\Resources\\LaporanApbdes\\Pages\\CreateLaporanApbdes',
    'app.filament.resources.laporan-apbdes.pages.edit-laporan-apbdes' => 'App\\Filament\\Resources\\LaporanApbdes\\Pages\\EditLaporanApbdes',
    'app.filament.resources.laporan-apbdes.pages.list-laporan-apbdes' => 'App\\Filament\\Resources\\LaporanApbdes\\Pages\\ListLaporanApbdes',
    'app.filament.resources.tahun-data-resource.pages.create-tahun-data' => 'App\\Filament\\Resources\\TahunDataResource\\Pages\\CreateTahunData',
    'app.filament.resources.tahun-data-resource.pages.edit-tahun-data' => 'App\\Filament\\Resources\\TahunDataResource\\Pages\\EditTahunData',
    'app.filament.resources.tahun-data-resource.pages.list-tahun-data' => 'App\\Filament\\Resources\\TahunDataResource\\Pages\\ListTahunData',
    'app.filament.resources.umkm-resource.pages.create-umkm' => 'App\\Filament\\Resources\\UmkmResource\\Pages\\CreateUmkm',
    'app.filament.resources.umkm-resource.pages.edit-umkm' => 'App\\Filament\\Resources\\UmkmResource\\Pages\\EditUmkm',
    'app.filament.resources.umkm-resource.pages.list-umkms' => 'App\\Filament\\Resources\\UmkmResource\\Pages\\ListUmkms',
    'app.filament.pages.dashboard' => 'App\\Filament\\Pages\\Dashboard',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Pages\\Dashboard.php' => 'App\\Filament\\Pages\\Dashboard',
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\project\\KKN\\web-desa\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\BeritaResource.php' => 'App\\Filament\\Resources\\BeritaResource',
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\DemografiDetailResource.php' => 'App\\Filament\\Resources\\DemografiDetailResource',
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\DemografiDusunResource.php' => 'App\\Filament\\Resources\\DemografiDusunResource',
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\DetailApbdesResource.php' => 'App\\Filament\\Resources\\DetailApbdesResource',
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\KategoriUmkmResource.php' => 'App\\Filament\\Resources\\KategoriUmkmResource',
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\LaporanApbdesResource.php' => 'App\\Filament\\Resources\\LaporanApbdesResource',
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\TahunDataResource.php' => 'App\\Filament\\Resources\\TahunDataResource',
    'D:\\project\\KKN\\web-desa\\app\\Filament\\Resources\\UmkmResource.php' => 'App\\Filament\\Resources\\UmkmResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\project\\KKN\\web-desa\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\project\\KKN\\web-desa\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);