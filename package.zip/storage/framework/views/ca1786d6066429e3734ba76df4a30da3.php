<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'image' => asset('images/logo-placeholder.jpg'),
    'url' => '#'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'image' => asset('images/logo-placeholder.jpg'),
    'url' => '#'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="rounded-2xl overflow-hidden p-8 flex flex-col items-center text-center">
    
    <div class="w-60 h-60 rounded-full overflow-hidden border-4 border-white shadow-md">
        <img src="<?php echo e($image); ?>" alt="" class="object-cover w-full h-full">
    </div>
</div>
<?php /**PATH D:\project\KKN\web-desa\resources\views\components\circle-image-frame.blade.php ENDPATH**/ ?>