<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'image' => asset('images/logo-placeholder.jpg'), //
    'title' => 'Judul Berita Default',
    'summary' => 'Ringkasan singkat...',
    'url' => '#'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'image' => asset('images/logo-placeholder.jpg'), //
    'title' => 'Judul Berita Default',
    'summary' => 'Ringkasan singkat...',
    'url' => '#'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden flex flex-col w-60 h-72">
    
    <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>" class="w-full h-32 object-cover">
    
    <div class="p-3 text-left flex flex-col flex-grow">
        <h3 class="font-semibold text-gray-800 dark:text-white text-sm line-clamp-2"><?php echo e($title); ?></h3>
        <p class="text-xs text-gray-600 dark:text-gray-400 mt-2 flex-grow line-clamp-3">
            <?php echo e($summary); ?>

        </p>
        
        <a href="<?php echo e($url); ?>" class="text-indigo-600 text-xs mt-3 inline-block hover:underline">
            Baca selengkapnya →
        </a>
    </div>
</div><?php /**PATH D:\project\KKN\web-desa\resources\views\components\news-card.blade.php ENDPATH**/ ?>