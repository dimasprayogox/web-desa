<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="grid grid-cols-1 gap-6">
        <!-- Header Info -->
        <div class="rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 p-6 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold">Dashboard UMKM</h1>
                    <p class="mt-1 text-blue-100">
                        Pantau dan analisis perkembangan UMKM di village Anda
                    </p>
                </div>
                <div class="text-right">
                    <div class="text-3xl font-bold">
                        <?php echo e(\App\Models\Umkm::count()); ?>

                    </div>
                    <div class="text-blue-100">Total UMKM</div>
                </div>
            </div>
        </div>
        
        <!-- Widgets Container -->
        <div class="space-y-6">
            <?php $__currentLoopData = $this->getWidgets(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split($widget);

$__html = app('livewire')->mount($__name, $__params, $widget, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <!-- Footer Info -->
        <div class="rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-700 dark:bg-gray-800">
            <div class="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                <div>
                    <span class="font-medium">Last Update:</span>
                    <?php echo e(now()->format('d M Y, H:i')); ?> WIB
                </div>
                <div class="flex items-center space-x-4">
                    <div>
                        <span class="font-medium">UMKM Aktif:</span>
                        <?php echo e(\App\Models\Umkm::where('status_usaha', 'aktif')->count()); ?>

                    </div>
                    <div>
                        <span class="font-medium">Total Omset:</span>
                        Rp <?php echo e(number_format(\App\Models\Umkm::where('status_usaha', 'aktif')->sum('omset_per_bulan'), 0, ',', '.')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?><?php /**PATH D:\project\KKN\web-desa\resources\views\filament\pages\umkm-dashboard.blade.php ENDPATH**/ ?>