<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['value', 'label']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['value', 'label']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="bg-gray-800 dark:bg-gray-800 text-center rounded-2xl py-8 px-6 shadow flex flex-col justify-center items-center min-h-[140px]">
  <h2 class="text-4xl font-extrabold text-blue-400 mb-3 leading-none">
    <?php echo e(number_format($value ?? 0, 0, ',', '.')); ?>

  </h2>
  <p class="text-sm font-semibold uppercase tracking-wide text-gray-300">
    <?php echo e($label); ?>

  </p>
</div>
<?php /**PATH D:\project\KKN\web-desa\resources\views\components\stat-box.blade.php ENDPATH**/ ?>