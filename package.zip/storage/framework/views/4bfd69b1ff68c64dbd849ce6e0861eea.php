<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Judul Default',
    'summary' => 'Deskripsi singkat',
    'image' => asset('images/logo-placeholder.jpg'),
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Judul Default',
    'summary' => 'Deskripsi singkat',
    'image' => asset('images/logo-placeholder.jpg'),
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="bg-white dark:bg-gray-800 rounded-2xl shadow-md overflow-hidden flex flex-col hover:shadow-lg transition duration-300 w-full h-full min-h-[280px] md:min-h-[320px]">
    <!-- Foto dengan tinggi tetap -->
    <div class="h-[180px] md:h-[220px] bg-gray-100 overflow-hidden flex-shrink-0">
        <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>" class="w-full h-full object-cover">
    </div>
    
    <!-- Content area dengan tinggi tetap -->
    <div class="p-3 md:p-4 flex flex-col justify-center text-center bg-gradient-to-b from-slate-50 to-white flex-grow h-[100px] md:h-[100px]">
        <h3 class="text-sm md:text-lg font-bold text-gray-800 dark:text-white mb-1 leading-tight line-clamp-2"><?php echo e($title); ?></h3>
        <p class="text-xs md:text-sm font-medium text-indigo-600 dark:text-indigo-400 leading-tight line-clamp-2">
            <?php echo e($summary); ?>

        </p>
    </div>
</div>
<?php /**PATH D:\project\KKN\web-desa\resources\views\components\card-info.blade.php ENDPATH**/ ?>